__all__ = ['irc', 'console', 'config', 'bot', 'stats2', 'scheduler']
